CREATE FULLTEXT INDEX name ON `groups`(name);
